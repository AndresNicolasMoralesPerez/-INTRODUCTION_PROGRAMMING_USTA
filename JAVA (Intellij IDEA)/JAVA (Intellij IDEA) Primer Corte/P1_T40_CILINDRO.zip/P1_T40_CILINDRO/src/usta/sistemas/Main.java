package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Andres Nicolas Morales Perez
	DATE: 19/03/2020
	DESCRIPTION: This program that calculate the volumen of a cilinder
	 */
	Scanner keyboard = new Scanner(System.in);
	System.out.println("This progam calculate the volumen of a cilinder, input the heigth");
	double heigth, radius,volumen;
	heigth= keyboard.nextDouble();
        System.out.println("Input the radius");
        radius= keyboard.nextDouble();
        System.out.println("input the volumen");
        volumen= keyboard.nextDouble();
      volumen = 3.1415*Math.pow(radius,2)*heigth;
        System.out.println("The volumen of the cilinder is"+ volumen);


    }
}
