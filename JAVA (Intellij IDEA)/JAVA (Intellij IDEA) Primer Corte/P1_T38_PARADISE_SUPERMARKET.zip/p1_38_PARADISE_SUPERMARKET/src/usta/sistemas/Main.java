package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Andres Nicolas Morales Perez
	DATE: 19/03/2020
	DESCRIPTION: This software generated a bill of supermarket paradise
	 */
        System.out.println("Bill software of super market paradise, input de first product:");
        Scanner keyboard = new Scanner(System.in);
        int prod1, prod2, prod3, prod4, Total_bruto;
        double IVA, TOTAL;
        prod1 = keyboard.nextInt();
        System.out.println("Input second product");
        prod2 = keyboard.nextInt();
        System.out.println("input third product");
        prod3 = keyboard.nextInt();
        System.out.println("input fourth product");
        prod4 = keyboard.nextInt();
        Total_bruto=prod1+prod2+prod3+prod4;
        IVA = Total_bruto*0.19;
        TOTAL = Total_bruto+IVA;
        System.out.println("Your bill is:");
        System.out.println("Total bruto: $" +Total_bruto);
        System.out.println("IVA: $" +IVA);
        System.out.println("Total factura: $"+ +TOTAL);
    }
}
