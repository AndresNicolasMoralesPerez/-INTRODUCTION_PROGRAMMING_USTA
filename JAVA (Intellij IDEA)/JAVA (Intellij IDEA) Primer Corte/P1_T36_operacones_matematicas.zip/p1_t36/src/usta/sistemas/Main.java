package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Nicolas Morales
	DATE: 12/03/2020
	DESCRIPTION: This software realize may mathematics operations whit four numbers
	 */
	Scanner keyboard = new Scanner(System.in);
	int x, y, resultint;
	double n, m, resultdouble;
        System.out.println("This software realize may mathematics operations whit four numbers");
        System.out.println("input the first integer number");
        x=keyboard.nextInt();
        System.out.println("input the second integer number");
        y=keyboard.nextInt();
        System.out.println("input the first double number");
        n=keyboard.nextDouble();
        System.out.println("input the second double number");
        m=keyboard.nextDouble();

    }
}
