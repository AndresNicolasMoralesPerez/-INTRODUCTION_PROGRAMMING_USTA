package usta.sistemas;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Andres Nicolas Morales
	DATE: 12/03/2020
	DESCRIPTION: This software add three variables and find the average the three variables
	 */
	Scanner keyboard = new Scanner(System.in);
            int v1, v2, v3, suma, average;
        System.out.println("this program add three variables, insert the first variable");
        v1=keyboard.nextInt();
        System.out.println("insert the second variable");
        v2=keyboard.nextInt();
        System.out.println("insert the third variable");
        v3=keyboard.nextInt();
        suma = v1+v2+v3;
        average= suma/3;

        System.out.println("the sumatory is:"+ suma);
        System.out.println("the averge is"+ average);
        System.out.println("this software is create for Nicolas Morales");


    }
}
