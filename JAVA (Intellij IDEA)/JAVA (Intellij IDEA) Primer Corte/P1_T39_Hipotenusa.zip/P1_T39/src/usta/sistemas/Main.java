package usta.sistemas;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Andres Nicolas Morales Perez
	DATE: 19/03/2020
	DESCRIPTION: This program calculate the hipotenusa the triangle
	 */
	Scanner keyboard= new Scanner(System.in);
	System.out.println("This program calculate hipotenusa the triangle input the first leg");
	double co, ca, hipotenusa;
	co = keyboard.nextDouble();
	System.out.println("Input the second leg");
	ca = keyboard.nextDouble();
	hipotenusa= Math.sqrt(Math.pow(co,2)+Math.pow(ca,2));
	System.out.println("This hipoteusa is:"+ hipotenusa);


    }
}
