package usta.sistemas;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Angel Manuel Correa Rivera
	DATE: 26/03/2020
	DESCRIPTION: This software print "Hello World" In the Screen.
	 */
        System.out.println("This software print \"Hello World\" In the Screen.");
        System.out.println("Hello World");

    }
}
