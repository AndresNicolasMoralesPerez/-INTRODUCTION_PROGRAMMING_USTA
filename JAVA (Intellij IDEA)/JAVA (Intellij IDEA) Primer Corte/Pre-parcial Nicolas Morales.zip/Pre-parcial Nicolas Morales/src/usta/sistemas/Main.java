package usta.sistemas;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR:Andres Nicolas Morales Perez
	DATE: 25/03/2020
	DESCRIPTION: This software helps determine if you have coronavirus (COVID-19)
	 */
        Scanner keyboard = new Scanner(System.in);
        int Cough, Body_ache, Dificult_Breathing, Age;
        double Degrees;
        System.out.println("Si tiene tos marque 1, Si no tiene tos marque 2");
        Cough = keyboard.nextInt();
        System.out.println("Si tiene dolor de cuerpo marque 1, Si no tiene tos marque 2");
        Body_ache = keyboard.nextInt();
        System.out.println("Si tiene dificulad para respirar marque 1, Si no tiene dificultad para respirar marque 2");
        Dificult_Breathing = keyboard.nextInt();
        System.out.println("Indique su temperaura (FIEBRE)");
        Degrees = keyboard.nextDouble();
        System.out.println("Indique su edad");
        Age = keyboard.nextInt();
        if (Cough == 1 && Body_ache == 1 && Dificult_Breathing == 1 && Degrees > 38) {
            System.out.println("Hay una gran posibilidad de que usted tenga COVID-19");
            if {(Age > 60)
                System.out.println("Debes contactrte inmediatamente con tu EPS");
            }
        }
        else {
            System.out.println("Tu no tienes COVID-19");
        }
    }
}





