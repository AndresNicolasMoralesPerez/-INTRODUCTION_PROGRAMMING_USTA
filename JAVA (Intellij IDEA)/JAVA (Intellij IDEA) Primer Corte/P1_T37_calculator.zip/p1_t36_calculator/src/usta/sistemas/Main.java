package usta.sistemas;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Andres Nicolas Morales Perez
	DATE: 14/03/2020
	DESCRIPTION: This softaware add variables int and double
	 */
	Scanner keyboard = new Scanner(System.in);
	int x, y, suma, resta, multiplicacion;
	double m, n, divison;
        System.out.println("insert the x variable");
        x=keyboard.nextInt();
        System.out.println("insert the y variable");
        y=keyboard.nextInt();
        System.out.println("insert the m variable");
        m=keyboard.nextDouble();
        System.out.println("insert the n variable");
        n=keyboard.nextDouble();
        suma = x+y;
        resta = x-y;
        multiplicacion = x*y;
        divison = x/y;

        System.out.println("The sumatory is:"+ suma);
        System.out.println("the substraction is"+ resta);
        System.out.println("the multiplication is"+ multiplicacion);
        System.out.println("the division is"+ divison);
        System.out.println("This software is create by Nicolas Morales System Engineiring");


    }
}
