package usta.sistemas;
import  java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	/*AUTHOR: Andres Nicolas Morales
	DATE: 12/03/2020
	DESCRIPTION: this software prints two birth years and their difference
	 */
	Scanner keyboard = new Scanner(System.in);
	int v1, v2, suma, difference;
        System.out.println("this program add birth years, insert first variable");
        v1=keyboard.nextInt();
        System.out.println("insert second variable");
        v2=keyboard.nextInt();
        suma=v1+v2;
        difference=v1-v2;
        System.out.println("this suma is"+ suma);
        System.out.println("this difference is"+ difference);
    }
}
